<?php

class CourtController extends Controller
{
    private $courtRepo;

    public function __construct($conn = null, array $config = [])
    {
        parent::__construct($conn, $config);
        $this->courtRepo = new CourtRepository();
    }

    public function index()
    {
        $courts = $this->courtRepo->all();
        $csrf = Csrf::generate();
        $this->view('courts/index', ['courts' => $courts, 'csrf' => $csrf]);
    }

    public function store()
    {
        Csrf::verifyOrFail();

        $validator = new Validator($_POST);
        $validator->required('name')->between('name', 3, 50);

        if (!$validator->passes()) {
            $_SESSION['error'] = implode(', ', $validator->errors());
            return $this->redirect('courts');
        }

        $data = [
            'name' => Sanitizer::name($_POST['name']),
            'type' => Sanitizer::alphanumeric($_POST['type'])
        ];

        $this->courtRepo->create($data);
        $_SESSION['success'] = "Lapangan baru berhasil ditambahkan!";
        $this->redirect('courts');
    }

    public function delete($id)
    {
        $this->courtRepo->delete($id);
        $_SESSION['success'] = "Lapangan berhasil dihapus!";
        $this->redirect('courts');
    }
}