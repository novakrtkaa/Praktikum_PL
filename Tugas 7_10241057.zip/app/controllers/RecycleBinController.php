<?php

class RecycleBinController extends Controller
{
    private $reservationRepo;

    public function __construct($conn = null, array $config = [])
    {
        parent::__construct($conn, $config);
        $this->reservationRepo = new ReservationRepository();
    }

    public function index()
    {
        $trashed = $this->reservationRepo->trashed();
        $csrf = Csrf::generate();
        $this->view('recyclebin/index', ['trashed' => $trashed, 'csrf' => $csrf]);
    }

    public function restore($id)
    {
        $this->reservationRepo->restore($id);
        $_SESSION['success'] = "Data berhasil dikembalikan.";
        $this->redirect('recyclebin');
    }

    public function destroy($id)
    {
        $this->reservationRepo->forceDelete($id);
        $_SESSION['success'] = "Data berhasil dihapus permanen.";
        $this->redirect('recyclebin');
    }

    public function restoreBulk()
    {
        Csrf::verifyOrFail();
        
        $ids = $_POST['selected'] ?? [];

        if (empty($ids)) {
            $_SESSION['error'] = "Tidak ada data yang dipilih.";
            return $this->redirect('recyclebin');
        }

        $this->reservationRepo->restoreBulk($ids);
        $_SESSION['success'] = count($ids) . " data berhasil dipulihkan.";
        $this->redirect('recyclebin');
    }

    public function deleteBulk()
    {
        Csrf::verifyOrFail();
        
        $ids = $_POST['selected'] ?? [];

        if (empty($ids)) {
            $_SESSION['error'] = "Tidak ada data yang dipilih.";
            return $this->redirect('recyclebin');
        }

        $this->reservationRepo->forceDeleteBulk($ids);
        $_SESSION['success'] = count($ids) . " data dihapus permanen.";
        $this->redirect('recyclebin');
    }

    public function autoDelete()
    {
        $count = $this->reservationRepo->autoDeleteOld(30);
        $_SESSION['success'] = "$count data lama dihapus permanen.";
        $this->redirect('recyclebin');
    }
}