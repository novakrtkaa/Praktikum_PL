<?php

class ReservationRepository
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function all($search = '', $sort = 'id', $order = 'ASC', $limit = 10, $offset = 0)
    {
        $query = "SELECT r.*, c.name AS court_name 
                  FROM reservations r 
                  JOIN courts c ON r.court_id = c.id
                  WHERE r.deleted_at IS NULL";

        if ($search) {
            $search = "%{$search}%";
            $query .= " AND (r.customer_name LIKE ? OR c.name LIKE ?)";
        }

        $query .= " ORDER BY {$sort} {$order} LIMIT ? OFFSET ?";

        if ($search) {
            $stmt = $this->db->query($query, [$search, $search, $limit, $offset]);
        } else {
            $stmt = $this->db->query($query, [$limit, $offset]);
        }

        return $stmt->fetchAll();
    }

    public function count($search = '')
    {
        $query = "SELECT COUNT(*) as total FROM reservations WHERE deleted_at IS NULL";
        $params = [];

        if ($search) {
            $query .= " AND (customer_name LIKE ?)";
            $params[] = "%{$search}%";
        }

        $stmt = $this->db->query($query, $params);
        return $stmt->fetch()['total'];
    }

    public function find($id)
    {
        $stmt = $this->db->query("SELECT * FROM reservations WHERE id = ?", [$id]);
        return $stmt->fetch();
    }

    public function create($data)
    {
        $sql = "INSERT INTO reservations (customer_name, court_id, start_time, end_time, status)
                VALUES (?, ?, ?, ?, ?)";
        $this->db->query($sql, [
            $data['customer_name'],
            $data['court_id'],
            $data['start_time'],
            $data['end_time'],
            $data['status']
        ]);
        return $this->db->lastInsertId();
    }

    public function update($id, $data)
    {
        $sql = "UPDATE reservations SET customer_name=?, court_id=?, start_time=?, end_time=?, status=? WHERE id=?";
        return $this->db->query($sql, [
            $data['customer_name'],
            $data['court_id'],
            $data['start_time'],
            $data['end_time'],
            $data['status'],
            $id
        ]);
    }

    public function softDelete($id)
    {
        $sql = "UPDATE reservations SET deleted_at=NOW() WHERE id=?";
        return $this->db->query($sql, [$id]);
    }

    public function restore($id)
    {
        $sql = "UPDATE reservations SET deleted_at=NULL WHERE id=?";
        return $this->db->query($sql, [$id]);
    }

    public function forceDelete($id)
    {
        $sql = "DELETE FROM reservations WHERE id=?";
        return $this->db->query($sql, [$id]);
    }

    public function restoreBulk($ids)
    {
        $in = str_repeat('?,', count($ids) - 1) . '?';
        $sql = "UPDATE reservations SET deleted_at=NULL WHERE id IN ($in)";
        return $this->db->query($sql, $ids);
    }

    public function forceDeleteBulk($ids)
    {
        $in = str_repeat('?,', count($ids) - 1) . '?';
        $sql = "DELETE FROM reservations WHERE id IN ($in)";
        return $this->db->query($sql, $ids);
    }

    public function autoDeleteOld($days = 30)
    {
        $sql = "DELETE FROM reservations WHERE deleted_at IS NOT NULL AND deleted_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
        $stmt = $this->db->query($sql, [$days]);
        return $stmt->rowCount();
    }

    public function trashed()
    {
        $stmt = $this->db->query("SELECT r.*, c.name AS court_name 
                                  FROM reservations r 
                                  JOIN courts c ON r.court_id = c.id
                                  WHERE r.deleted_at IS NOT NULL
                                  ORDER BY deleted_at DESC");
        return $stmt->fetchAll();
    }
}
