<?php
return [
    'base_url' => 'http://localhost/badminton_mvc/public/',
    'db' => [
        'host' => 'localhost',
        'user' => 'root',
        'pass' => '',
        'name' => 'badminton_mvc',
    ]
];