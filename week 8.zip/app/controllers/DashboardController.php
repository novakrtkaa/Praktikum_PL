<?php
// File: app/controllers/DashboardController.php

class DashboardController extends Controller
{
    private $auth;
    private $middleware;
    private $reservationRepo;
    private $courtRepo;
    private $userRepo;

    public function __construct($conn = null, array $config = [])
    {
        parent::__construct($conn, $config);
        $this->auth = Auth::getInstance();
        $this->middleware = new Middleware();
        $this->reservationRepo = new ReservationRepository();
        $this->courtRepo = new CourtRepository();
        $this->userRepo = new UserRepository();
    }

    /**
     * Dashboard utama - redirect sesuai role
     */
    public function index()
    {
        $this->middleware->auth();
        
        $role = $this->auth->role();
        
        switch ($role) {
            case 'admin':
                return $this->adminDashboard();
            case 'manager':
                return $this->managerDashboard();
            case 'staff':
                return $this->staffDashboard();
            default:
                $_SESSION['error'] = 'Role tidak dikenali.';
                $this->redirect('auth/logout');
        }
    }

    /**
     * Dashboard Admin - Full access
     */
    private function adminDashboard()
    {
        // Statistics
        $totalReservations = $this->reservationRepo->count();
        $totalCourts = count($this->courtRepo->all());
        $totalUsers = count($this->userRepo->all());
        $totalAdmins = $this->userRepo->countByRole('admin');
        $totalManagers = $this->userRepo->countByRole('manager');
        $totalStaff = $this->userRepo->countByRole('staff');
        
        // Recent reservations
        $recentReservations = $this->reservationRepo->all('', 'id', 'DESC', 5, 0);
        
        // Trashed items
        $trashedCount = count($this->reservationRepo->trashed());
        
        $data = [
            'user' => $this->auth->user(),
            'stats' => [
                'reservations' => $totalReservations,
                'courts' => $totalCourts,
                'users' => $totalUsers,
                'admins' => $totalAdmins,
                'managers' => $totalManagers,
                'staff' => $totalStaff,
                'trashed' => $trashedCount
            ],
            'recent_reservations' => $recentReservations
        ];
        
        $this->view('dashboard/admin', $data);
    }

    /**
     * Dashboard Manager - Manage courts and reservations
     */
    private function managerDashboard()
    {
        // Statistics
        $totalReservations = $this->reservationRepo->count();
        $totalCourts = count($this->courtRepo->all());
        
        // Recent reservations
        $recentReservations = $this->reservationRepo->all('', 'id', 'DESC', 10, 0);
        
        $data = [
            'user' => $this->auth->user(),
            'stats' => [
                'reservations' => $totalReservations,
                'courts' => $totalCourts
            ],
            'recent_reservations' => $recentReservations
        ];
        
        $this->view('dashboard/manager', $data);
    }

    /**
     * Dashboard Staff - Limited access
     */
    private function staffDashboard()
    {
        // Recent reservations
        $recentReservations = $this->reservationRepo->all('', 'id', 'DESC', 10, 0);
        
        $data = [
            'user' => $this->auth->user(),
            'recent_reservations' => $recentReservations
        ];
        
        $this->view('dashboard/staff', $data);
    }

    /**
     * Profile page
     */
    public function profile()
    {
        $this->middleware->auth();
        
        $user = $this->auth->user();
        $csrf = Csrf::generate();
        
        $this->view('dashboard/profile', [
            'user' => $user,
            'csrf' => $csrf
        ]);
    }

    /**
     * Update password
     */
    public function updatePassword()
    {
        $this->middleware->auth();
        Csrf::verifyOrFail();

        $validator = new Validator($_POST);
        $validator->required('current_password')
                  ->required('new_password')
                  ->between('new_password', 6, 50)
                  ->required('confirm_password');

        if (!$validator->passes()) {
            $_SESSION['error'] = implode(', ', $validator->errors());
            return $this->redirect('dashboard/profile');
        }

        // Verify current password
        if (!$this->auth->user()->verifyPassword($_POST['current_password'])) {
            $_SESSION['error'] = 'Password lama tidak sesuai.';
            return $this->redirect('dashboard/profile');
        }

        // Check if new password matches confirmation
        if ($_POST['new_password'] !== $_POST['confirm_password']) {
            $_SESSION['error'] = 'Konfirmasi password tidak cocok.';
            return $this->redirect('dashboard/profile');
        }

        // Update password
        $this->userRepo->updatePassword($this->auth->id(), $_POST['new_password']);
        
        $_SESSION['success'] = 'Password berhasil diubah.';
        $this->redirect('dashboard/profile');
    }
}