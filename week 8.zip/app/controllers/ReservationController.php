<?php
// File: app/controllers/ReservationController.php (UPDATED)

class ReservationController extends Controller
{
    private $reservationRepo;
    private $courtRepo;
    private $auth;
    private $middleware;

    public function __construct($conn = null, array $config = [])
    {
        parent::__construct($conn, $config);
        $this->reservationRepo = new ReservationRepository();
        $this->courtRepo = new CourtRepository();
        $this->auth = Auth::getInstance();
        $this->middleware = new Middleware();
    }

    public function index()
    {
        // Require authentication
        $this->middleware->auth();
        
        $search = $_GET['search'] ?? '';
        $sort = $_GET['sort'] ?? 'id';
        $order = $_GET['order'] ?? 'DESC';
        $page = $_GET['page'] ?? 1;
        $limit = 5;
        $offset = ($page - 1) * $limit;

        $reservations = $this->reservationRepo->all($search, $sort, $order, $limit, $offset);
        $total = $this->reservationRepo->count($search);
        $pages = ceil($total / $limit);

        $this->view('reservations/index', [
            'reservations' => $reservations,
            'search' => $search,
            'sort' => $sort,
            'order' => $order,
            'page' => $page,
            'pages' => $pages
        ]);
    }

    public function create()
    {
        // Require authentication
        $this->middleware->auth();
        
        $courts = $this->courtRepo->all();
        $csrf = Csrf::generate();
        $this->view('reservations/create', ['courts' => $courts, 'csrf' => $csrf]);
    }

    public function store()
    {
        // Require authentication
        $this->middleware->auth();
        
        Csrf::verifyOrFail();

        $validator = new Validator($_POST);
        $validator->required('customer_name')
                  ->between('customer_name', 3, 50)
                  ->numeric('court_id')
                  ->dateFormat('start_time', 'Y-m-d\TH:i')
                  ->dateFormat('end_time', 'Y-m-d\TH:i');

        if (!$validator->passes()) {
            $_SESSION['error'] = implode(', ', $validator->errors());
            return $this->redirect('reservation/create');
        }

        $data = [
            'customer_name' => Sanitizer::name($_POST['customer_name']),
            'court_id' => $_POST['court_id'],
            'start_time' => $_POST['start_time'],
            'end_time' => $_POST['end_time'],
            'status' => $_POST['status']
        ];

        $this->reservationRepo->create($data);
        $_SESSION['success'] = "Reservasi berhasil ditambahkan!";
        $this->redirect('reservation');
    }

    public function edit($id)
    {
        // Require authentication
        $this->middleware->auth();
        
        $reservation = $this->reservationRepo->find($id);
        $courts = $this->courtRepo->all();
        $csrf = Csrf::generate();
        $this->view('reservations/edit', [
            'reservation' => $reservation,
            'courts' => $courts,
            'csrf' => $csrf
        ]);
    }

    public function update($id)
    {
        // Require authentication
        $this->middleware->auth();
        
        Csrf::verifyOrFail();
        
        $data = [
            'customer_name' => Sanitizer::name($_POST['customer_name']),
            'court_id' => $_POST['court_id'],
            'start_time' => $_POST['start_time'],
            'end_time' => $_POST['end_time'],
            'status' => $_POST['status']
        ];
        
        $this->reservationRepo->update($id, $data);
        $_SESSION['success'] = "Data reservasi berhasil diperbarui!";
        $this->redirect('reservation');
    }

    public function delete($id)
    {
        // Require authentication and permission
        $this->middleware->auth();
        
        $this->reservationRepo->softDelete($id);
        $_SESSION['success'] = "Data berhasil dipindahkan ke Recycle Bin.";
        $this->redirect('reservation');
    }
}