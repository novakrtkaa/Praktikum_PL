<?php

class Court
{
    public $id;
    public $name;
    public $type;
}
