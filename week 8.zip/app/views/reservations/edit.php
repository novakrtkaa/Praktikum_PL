<?php include_once __DIR__ . '/../layouts/header.php'; ?>

<h2>Edit Reservasi</h2>

<form method="POST" action="<?= $base_url ?>?c=reservation&a=update&id=<?= $reservation['id'] ?>">
    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">

    <label>Nama Pelanggan</label>
    <input type="text" name="customer_name" value="<?= htmlspecialchars($reservation['customer_name']) ?>" required>

    <label>Lapangan</label>
    <select name="court_id" required>
        <?php foreach ($courts as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $c['id'] == $reservation['court_id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['name']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Waktu Mulai</label>
    <input type="datetime-local" name="start_time" 
           value="<?= date('Y-m-d\TH:i', strtotime($reservation['start_time'])) ?>" required>

    <label>Waktu Selesai</label>
    <input type="datetime-local" name="end_time" 
           value="<?= date('Y-m-d\TH:i', strtotime($reservation['end_time'])) ?>" required>

    <label>Status</label>
    <select name="status">
        <option value="aktif" <?= $reservation['status'] == 'aktif' ? 'selected' : '' ?>>Aktif</option>
        <option value="selesai" <?= $reservation['status'] == 'selesai' ? 'selected' : '' ?>>Selesai</option>
    </select>

    <button class="btn" type="submit">Update</button>
    <a href="<?= $base_url ?>?c=reservation&a=index" class="btn btn-secondary">Batal</a>
</form>

<?php include_once __DIR__ . '/../layouts/footer.php'; ?>