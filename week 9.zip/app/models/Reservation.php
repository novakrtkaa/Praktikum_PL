<?php

class Reservation
{
    public $id;
    public $customer_name;
    public $court_id;
    public $start_time;
    public $end_time;
    public $status;
    public $deleted_at;
}
