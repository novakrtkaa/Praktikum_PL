<!-- File: app/views/dashboard/manager.php -->
<?php $title = 'Manager Dashboard'; ?>
<?php include_once __DIR__ . '/../layouts/dashboard_header.php'; ?>

<div class="top-bar">
    <h1>📊 Manager Dashboard</h1>
    <p>Selamat datang, <?= htmlspecialchars($user->getFullName()) ?>! Kelola lapangan dan reservasi.</p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="icon">📅</div>
        <div class="label">Total Reservasi</div>
        <div class="value"><?= $stats['reservations'] ?></div>
    </div>
    
    <div class="stat-card">
        <div class="icon">🏟️</div>
        <div class="label">Total Lapangan</div>
        <div class="value"><?= $stats['courts'] ?></div>
    </div>
</div>

<div class="content-card">
    <h3>📋 Daftar Reservasi</h3>
    
    <?php if (empty($recent_reservations)): ?>
        <p style="text-align: center; color: #999; padding: 40px;">Belum ada data reservasi.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Customer</th>
                    <th>Lapangan</th>
                    <th>Waktu Mulai</th>
                    <th>Waktu Selesai</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_reservations as $r): ?>
                <tr>
                    <td><?= $r['id'] ?></td>
                    <td><?= htmlspecialchars($r['customer_name']) ?></td>
                    <td><?= htmlspecialchars($r['court_name']) ?></td>
                    <td><?= DateHelper::format($r['start_time'], 'd M Y H:i') ?></td>
                    <td><?= DateHelper::format($r['end_time'], 'H:i') ?></td>
                    <td>
                        <span class="badge badge-<?= $r['status'] === 'aktif' ? 'active' : 'completed' ?>">
                            <?= ucfirst($r['status']) ?>
                        </span>
                    </td>
                    <td>
                        <a href="<?= $base_url ?>?c=reservation&a=edit&id=<?= $r['id'] ?>" 
                           style="color: #667eea; text-decoration: none;">Edit</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="content-card">
    <h3>⚡ Quick Actions</h3>
    <div style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 20px;">
        <a href="<?= $base_url ?>?c=reservation&a=create" 
           style="padding: 12px 24px; background: #764ba2; color: white; text-decoration: none; border-radius: 8px; display: inline-block;">
            📅 Buat Reservasi Baru
        </a>
        <a href="<?= $base_url ?>?c=court&a=index" 
           style="padding: 12px 24px; background: #f57c00; color: white; text-decoration: none; border-radius: 8px; display: inline-block;">
            🏟️ Kelola Lapangan
        </a>
        <a href="<?= $base_url ?>?c=reservation&a=index" 
           style="padding: 12px 24px; background: #667eea; color: white; text-decoration: none; border-radius: 8px; display: inline-block;">
            📋 Lihat Semua Reservasi
        </a>
    </div>
</div>

<?php include_once __DIR__ . '/../layouts/dashboard_footer.php'; ?>