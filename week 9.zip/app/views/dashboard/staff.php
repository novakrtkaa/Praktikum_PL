<!-- File: app/views/dashboard/staff.php -->
<?php $title = 'Staff Dashboard'; ?>
<?php include_once __DIR__ . '/../layouts/dashboard_header.php'; ?>

<div class="top-bar">
    <h1>👤 Staff Dashboard</h1>
    <p>Selamat datang, <?= htmlspecialchars($user->getFullName()) ?>! Kelola reservasi pelanggan.</p>
</div>

<div class="content-card">
    <h3>📋 Reservasi Terbaru</h3>
    
    <?php if (empty($recent_reservations)): ?>
        <p style="text-align: center; color: #999; padding: 40px;">Belum ada data reservasi.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Customer</th>
                    <th>Lapangan</th>
                    <th>Waktu Mulai</th>
                    <th>Waktu Selesai</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_reservations as $r): ?>
                <tr>
                    <td><?= $r['id'] ?></td>
                    <td><?= htmlspecialchars($r['customer_name']) ?></td>
                    <td><?= htmlspecialchars($r['court_name']) ?></td>
                    <td><?= DateHelper::format($r['start_time'], 'd M Y H:i') ?></td>
                    <td><?= DateHelper::format($r['end_time'], 'H:i') ?></td>
                    <td>
                        <span class="badge badge-<?= $r['status'] === 'aktif' ? 'active' : 'completed' ?>">
                            <?= ucfirst($r['status']) ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="content-card">
    <h3>⚡ Quick Actions</h3>
    <div style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 20px;">
        <a href="<?= $base_url ?>?c=reservation&a=create" 
           style="padding: 12px 24px; background: #764ba2; color: white; text-decoration: none; border-radius: 8px; display: inline-block;">
            ➕ Buat Reservasi Baru
        </a>
        <a href="<?= $base_url ?>?c=reservation&a=index" 
           style="padding: 12px 24px; background: #667eea; color: white; text-decoration: none; border-radius: 8px; display: inline-block;">
            📋 Lihat Semua Reservasi
        </a>
    </div>
</div>

<div class="content-card">
    <h3>ℹ️ Informasi</h3>
    <p style="color: #666; line-height: 1.6;">
        Sebagai Staff, Anda dapat:
    </p>
    <ul style="color: #666; line-height: 2; margin-top: 15px; margin-left: 20px;">
        <li>✅ Membuat reservasi baru untuk pelanggan</li>
        <li>✅ Melihat daftar semua reservasi</li>
        <li>✅ Mencari reservasi berdasarkan nama atau lapangan</li>
        <li>❌ Tidak dapat mengelola lapangan</li>
        <li>❌ Tidak dapat mengelola user lain</li>
    </ul>
</div>

<?php include_once __DIR__ . '/../layouts/dashboard_footer.php'; ?>