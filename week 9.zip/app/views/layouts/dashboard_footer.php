<!-- File: app/views/layouts/dashboard_footer.php -->
        </main>
    </div>
</body>
</html>