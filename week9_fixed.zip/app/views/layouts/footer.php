</div>
<footer style="text-align:center; padding:1rem; color:#777;">
    <p>&copy; <?= date('Y') ?> Sistem Reservasi Badminton</p>
</footer>
</body>
</html>
